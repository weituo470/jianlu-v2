<template>
	<view class="home-container">
		<!-- Banner 轮播图 -->
		<view class="banner-section" v-if="bannerList.length > 0">
			<swiper 
				class="banner-swiper"
				:indicator-dots="true"
				:autoplay="true"
				:interval="4000"
				:duration="500"
				:circular="true"
				indicator-active-color="#007aff"
				indicator-color="rgba(255,255,255,0.5)"
			>
				<swiper-item 
					v-for="banner in bannerList" 
					:key="banner.id"
					@tap="onBannerTap(banner)"
				>
					<view class="banner-item">
						<image 
							:src="getImageUrl(banner.image_url)" 
							class="banner-image"
							mode="aspectFill"
							:lazy-load="true"
							@error="onImageError"
						/>
						<view class="banner-overlay" v-if="banner.title || banner.description">
							<view class="banner-content">
								<text class="banner-title" v-if="banner.title">{{ banner.title }}</text>
								<text class="banner-description" v-if="banner.description">{{ banner.description }}</text>
							</view>
						</view>
					</view>
				</swiper-item>
			</swiper>
		</view>
		
		<!-- 顶部欢迎区域 -->
		<view class="welcome-section">
			<view class="welcome-header">
				<view class="user-info">
					<view class="avatar">
						<image 
							v-if="userInfo.avatar" 
							:src="userInfo.avatar" 
							class="avatar-image"
							mode="aspectFill"
						/>
						<text v-else class="avatar-text">
							{{ (userInfo.nickname || userInfo.username || '').charAt(0) }}
						</text>
					</view>
					<view class="user-details">
						<text class="welcome-text">你好，{{ userInfo.nickname || userInfo.username }}！</text>
						<text class="welcome-subtitle">欢迎来到简庐团队协作平台</text>
					</view>
				</view>
				<view class="notification-icon" @tap="goToMessages">
					<text class="icon">🔔</text>
					<view class="badge" v-if="unreadCount > 0">{{ unreadCount > 99 ? '99+' : unreadCount }}</view>
				</view>
			</view>
		</view>
		
		<!-- 快捷功能区 -->
		<view class="quick-actions">
			<text class="section-title">快捷功能</text>
			<view class="action-grid">
				<view class="action-item" @tap="createTeam">
					<view class="action-icon">👥</view>
					<text class="action-text">创建团队</text>
				</view>
				<view class="action-item" @tap="createActivity">
					<view class="action-icon">📅</view>
					<text class="action-text">发起活动</text>
				</view>
				<view class="action-item" @tap="joinTeam">
					<view class="action-icon">🔗</view>
					<text class="action-text">加入团队</text>
				</view>
				<view class="action-item" @tap="viewCalendar">
					<view class="action-icon">📆</view>
					<text class="action-text">日程安排</text>
				</view>
			</view>
		</view>
		
		<!-- 最近活动 -->
		<view class="recent-activities">
			<view class="section-header">
				<text class="section-title">最近活动</text>
				<text class="more-link" @tap="goToActivities">查看更多</text>
			</view>
			
			<view class="activity-list" v-if="recentActivities.length > 0">
				<view 
					class="activity-item" 
					v-for="activity in recentActivities" 
					:key="activity.id"
					@tap="viewActivity(activity)"
				>
					<view class="activity-info">
						<text class="activity-title">{{ activity.title }}</text>
						<text class="activity-team">{{ activity.team_name }}</text>
						<text class="activity-time">{{ formatDate(activity.start_time, 'MM月DD日 HH:mm') }}</text>
					</view>
					<view class="activity-status" :class="getActivityStatus(activity.start_time, activity.end_time)">
						{{ getActivityStatusText(activity.start_time, activity.end_time) }}
					</view>
				</view>
			</view>
			
			<view class="empty-state" v-else>
				<text class="empty-icon">📅</text>
				<text class="empty-text">暂无最近活动</text>
			</view>
		</view>
		
		<!-- 我的团队 -->
		<view class="my-teams">
			<view class="section-header">
				<text class="section-title">我的团队</text>
				<text class="more-link" @tap="goToTeams">查看更多</text>
			</view>
			
			<view class="team-list" v-if="myTeams.length > 0">
				<view 
					class="team-item" 
					v-for="team in myTeams" 
					:key="team.id"
					@tap="viewTeam(team)"
				>
					<view class="team-avatar">
						{{ team.name.charAt(0) }}
					</view>
					<view class="team-info">
						<text class="team-name">{{ team.name }}</text>
						<text class="team-members">{{ team.member_count }} 成员</text>
					</view>
					<view class="team-role" :class="team.role">
						{{ team.role === 'admin' ? '管理员' : '成员' }}
					</view>
				</view>
			</view>
			
			<view class="empty-state" v-else>
				<text class="empty-icon">👥</text>
				<text class="empty-text">暂未加入任何团队</text>
			</view>
		</view>
	</view>
</template>

<script>
	import { groupApi, activityApi, bannerApi } from '../../api/index.js'
	import { formatDate, getActivityStatus, getActivityStatusText, showSuccess, showError } from '../../utils/index.js'
	import envConfig from '../../config/env.js'
	
	export default {
		data() {
			return {
				userInfo: {},
				unreadCount: 0,
				recentActivities: [],
				myTeams: [],
				bannerList: [], // 轮播图列表
				loading: false
			}
		},
		onLoad() {
			this.userInfo = uni.getStorageSync('userInfo') || {}
			this.loadData()
		},
		onShow() {
			this.loadData()
		},
		onPullDownRefresh() {
			this.loadData().finally(() => {
				uni.stopPullDownRefresh()
			})
		},
		methods: {
			formatDate,
			getActivityStatus,
			getActivityStatusText,
			
			// 加载数据
			async loadData() {
				this.loading = true
				try {
					await Promise.all([
						this.loadBanners(),
						this.loadRecentActivities(),
						this.loadMyTeams(),
						this.loadUnreadCount()
					])
				} catch (error) {
					console.error('加载数据失败:', error)
				} finally {
					this.loading = false
				}
			},
			
			// 加载轮播图
			async loadBanners() {
				try {
					const response = await bannerApi.getList()
					if (response.success) {
						// 公开接口直接返回轮播图数组
						this.bannerList = Array.isArray(response.data) ? response.data : []
						console.log('轮播图加载成功:', this.bannerList.length, '张')
					} else {
						console.error('轮播图加载失败:', response.message)
						this.bannerList = []
					}
				} catch (error) {
					console.error('轮播图加载异常:', error)
					this.bannerList = []
				}
			},
			
			// 加载最近活动
			async loadRecentActivities() {
				try {
					const response = await activityApi.getList()
					if (response.success) {
						// 修复：活动数据在 response.data.activities 中
						const activities = response.data.activities || response.data || []
						this.recentActivities = Array.isArray(activities) ? activities.slice(0, 3) : []
					}
				} catch (error) {
					console.error('加载活动失败:', error)
				}
			},
			
			// 加载我的团队
			async loadMyTeams() {
				try {
					const response = await groupApi.getList()
					if (response.success) {
						// 修复：团队数据在 response.data.teams 中
						const teams = response.data.teams || response.data || []
						this.myTeams = Array.isArray(teams) ? teams.slice(0, 3) : []
					}
				} catch (error) {
					console.error('加载团队失败:', error)
				}
			},
			
			// 加载未读消息数量
			async loadUnreadCount() {
				// TODO: 实现未读消息数量API
				this.unreadCount = 0
			},
			
			// 跳转到消息页面
			goToMessages() {
				uni.switchTab({
					url: '/pages/message/message'
				})
			},
			
			// 跳转到活动页面
			goToActivities() {
				uni.switchTab({
					url: '/pages/activity/activity'
				})
			},
			
			// 跳转到团队页面
			goToTeams() {
				uni.switchTab({
					url: '/pages/team/team'
				})
			},
			
			// 处理图片URL
			getImageUrl(imageUrl) {
				if (!imageUrl) return ''
				
				// 如果已经是完整URL，直接返回
				if (imageUrl.startsWith('http://') || imageUrl.startsWith('https://')) {
					return imageUrl
				}
				
				// 处理相对路径，转换为完整URL
				const baseUrl = envConfig.IMAGE_BASE_URL
				return baseUrl + (imageUrl.startsWith('/') ? imageUrl : '/' + imageUrl)
			},
			
			// 图片加载错误处理
			onImageError(e) {
				console.error('图片加载失败:', e)
				uni.showToast({
					title: '图片加载失败',
					icon: 'none',
					duration: 2000
				})
			},
			
			// Banner 点击事件
			onBannerTap(banner) {
				console.log('点击轮播图:', banner)
				
				// 如果有链接地址，处理跳转
				if (banner.link_url) {
					// 判断是否为外部链接
					if (banner.link_url.startsWith('http://') || banner.link_url.startsWith('https://')) {
						// 复制链接到剪贴板并提示用户
						uni.setClipboardData({
							data: banner.link_url,
							success: () => {
								uni.showModal({
									title: '提示',
									content: '链接已复制到剪贴板，请在浏览器中打开',
									showCancel: false
								})
							}
						})
					} else {
						// 内部链接，直接跳转
						if (banner.link_url.startsWith('/')) {
							// 页面路径跳转
							uni.navigateTo({
								url: banner.link_url
							}).catch(() => {
								// 如果 navigateTo 失败，尝试 switchTab
								uni.switchTab({
									url: banner.link_url
								}).catch(() => {
									uni.showToast({
										title: '页面跳转失败',
										icon: 'none'
									})
								})
							})
						}
					}
				} else {
					// 没有链接，显示轮播图详情
					uni.showModal({
						title: banner.title || '轮播图',
						content: banner.description || '暂无描述',
						showCancel: false
					})
				}
			},
			
			// 创建团队
			createTeam() {
				uni.switchTab({
					url: '/pages/team/team'
				})
				// 可以通过事件总线或其他方式通知团队页面显示创建弹窗
			},
			
			// 发起活动
			createActivity() {
				uni.switchTab({
					url: '/pages/activity/activity'
				})
			},
			
			// 加入团队
			joinTeam() {
				uni.showModal({
					title: '加入团队',
					content: '请输入团队邀请码',
					editable: true,
					success: (res) => {
						if (res.confirm && res.content) {
							// TODO: 实现加入团队逻辑
							showSuccess('加入团队成功')
							this.loadMyTeams()
						}
					}
				})
			},
			
			// 查看日程
			viewCalendar() {
				uni.showToast({
					title: '功能开发中',
					icon: 'none'
				})
			},
			
			// 查看活动详情
			viewActivity(activity) {
				// TODO: 跳转到活动详情页面
				uni.showModal({
					title: activity.title,
					content: `时间: ${formatDate(activity.start_time, 'YYYY年MM月DD日 HH:mm')}\n团队: ${activity.team_name}`,
					showCancel: false
				})
			},
			
			// 查看团队详情
			viewTeam(team) {
				// TODO: 跳转到团队详情页面
				uni.showModal({
					title: team.name,
					content: `成员数量: ${team.member_count}\n我的角色: ${team.role === 'admin' ? '管理员' : '成员'}`,
					showCancel: false
				})
			}
		}
	}
</script>

<style scoped>
	.home-container {
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	
	/* Banner 轮播图样式 */
	.banner-section {
		width: 100%;
		height: 360rpx;
		position: relative;
	}
	
	.banner-swiper {
		width: 100%;
		height: 100%;
	}
	
	.banner-item {
		position: relative;
		width: 100%;
		height: 100%;
	}
	
	.banner-image {
		width: 100%;
		height: 100%;
		object-fit: cover;
		display: block;
	}
	
	.banner-overlay {
		position: absolute;
		bottom: 0;
		left: 0;
		right: 0;
		background: linear-gradient(transparent, rgba(0, 0, 0, 0.6));
		padding: 40rpx 30rpx 30rpx;
	}
	
	.banner-content {
		color: white;
	}
	
	.banner-title {
		font-size: 32rpx;
		font-weight: bold;
		line-height: 1.4;
		margin-bottom: 10rpx;
		display: block;
		text-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.3);
	}
	
	.banner-description {
		font-size: 26rpx;
		line-height: 1.4;
		opacity: 0.9;
		display: block;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		text-shadow: 0 2rpx 4rpx rgba(0, 0, 0, 0.3);
	}
	
	.welcome-section {
		background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
		padding: 40rpx 30rpx 30rpx;
		color: white;
	}
	
	.welcome-header {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	
	.user-info {
		display: flex;
		align-items: center;
	}
	
	.avatar {
		width: 100rpx;
		height: 100rpx;
		border-radius: 50rpx;
		background: rgba(255, 255, 255, 0.2);
		display: flex;
		align-items: center;
		justify-content: center;
		margin-right: 20rpx;
		overflow: hidden;
	}
	
	.avatar-image {
		width: 100%;
		height: 100%;
		border-radius: 50rpx;
	}
	
	.avatar-text {
		color: white;
		font-size: 40rpx;
		font-weight: bold;
	}
	
	.welcome-text {
		font-size: 32rpx;
		font-weight: bold;
		display: block;
		margin-bottom: 8rpx;
		line-height: 1.3;
		word-wrap: break-word;
		word-break: break-all;
	}
	
	.welcome-subtitle {
		font-size: 24rpx;
		opacity: 0.8;
		display: block;
	}
	
	.notification-icon {
		position: relative;
		width: 60rpx;
		height: 60rpx;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	
	.icon {
		font-size: 32rpx;
	}
	
	.badge {
		position: absolute;
		top: -5rpx;
		right: -5rpx;
		background: #ff3b30;
		color: white;
		font-size: 20rpx;
		padding: 4rpx 8rpx;
		border-radius: 12rpx;
		min-width: 24rpx;
		text-align: center;
	}
	
	.quick-actions {
		padding: 30rpx;
		background: white;
		margin: 20rpx;
		border-radius: 16rpx;
	}
	
	.section-title {
		font-size: 32rpx;
		font-weight: bold;
		color: #333;
		display: block;
		margin-bottom: 20rpx;
	}
	
	.action-grid {
		display: grid;
		grid-template-columns: repeat(4, 1fr);
		gap: 20rpx;
	}
	
	.action-item {
		display: flex;
		flex-direction: column;
		align-items: center;
		padding: 20rpx;
		border-radius: 12rpx;
		background: #f8f9fa;
	}
	
	.action-icon {
		font-size: 40rpx;
		margin-bottom: 12rpx;
	}
	
	.action-text {
		font-size: 24rpx;
		color: #666;
		text-align: center;
	}
	
	.recent-activities, .my-teams {
		margin: 20rpx;
		background: white;
		border-radius: 16rpx;
		padding: 30rpx;
	}
	
	.section-header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 20rpx;
	}
	
	.more-link {
		font-size: 24rpx;
		color: #007aff;
	}
	
	.activity-item, .team-item {
		display: flex;
		align-items: center;
		padding: 20rpx 0;
		border-bottom: 1rpx solid #f0f0f0;
	}
	
	.activity-item:last-child, .team-item:last-child {
		border-bottom: none;
	}
	
	.activity-info, .team-info {
		flex: 1;
	}
	
	.activity-title, .team-name {
		font-size: 28rpx;
		font-weight: bold;
		color: #333;
		display: block;
		margin-bottom: 8rpx;
		line-height: 1.3;
		word-wrap: break-word;
		word-break: break-all;
		/* 限制最多显示1行 */
		display: -webkit-box;
		-webkit-line-clamp: 1;
		-webkit-box-orient: vertical;
		overflow: hidden;
	}
	
	.activity-team, .activity-time, .team-members {
		font-size: 24rpx;
		color: #666;
		display: block;
		margin-bottom: 4rpx;
	}
	
	.activity-status, .team-role {
		font-size: 20rpx;
		padding: 8rpx 16rpx;
		border-radius: 12rpx;
		color: white;
		font-weight: bold;
	}
	
	.activity-status.upcoming {
		background: #007aff;
	}
	
	.activity-status.ongoing {
		background: #28a745;
	}
	
	.activity-status.ended {
		background: #6c757d;
	}
	
	.team-role.admin {
		background: #ff3b30;
	}
	
	.team-role.member {
		background: #007aff;
	}
	
	.team-avatar {
		width: 60rpx;
		height: 60rpx;
		border-radius: 30rpx;
		background: #007aff;
		display: flex;
		align-items: center;
		justify-content: center;
		color: white;
		font-size: 24rpx;
		font-weight: bold;
		margin-right: 20rpx;
	}
	
	.empty-state {
		text-align: center;
		padding: 60rpx 20rpx;
	}
	
	.empty-icon {
		font-size: 80rpx;
		display: block;
		margin-bottom: 20rpx;
	}
	
	.empty-text {
		font-size: 28rpx;
		color: #999;
	}
</style>
