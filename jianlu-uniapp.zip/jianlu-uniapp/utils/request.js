// HTTP请求工具
import envConfig from '../config/env.js'

const BASE_URL = envConfig.API_BASE_URL

// 请求拦截器
const request = (options) => {
	return new Promise((resolve, reject) => {
		// 添加token
		const token = uni.getStorageSync('token')
		const header = {
			'Content-Type': 'application/json',
			...options.header
		}
		
		if (token) {
			header.Authorization = `Bearer ${token}`
		}
		
		// 处理GET请求的查询参数
		let fullUrl = BASE_URL + options.url
		let requestData = options.data || {}

		// 如果是GET请求且有参数，将参数添加到URL中
		if ((options.method || 'GET') === 'GET' && Object.keys(requestData).length > 0) {
			// 手动构建查询字符串，兼容小程序环境
			const queryString = Object.keys(requestData)
				.map(key => {
					const value = requestData[key]
					if (value === null || value === undefined) return ''
					return `${encodeURIComponent(key)}=${encodeURIComponent(value)}`
				})
				.filter(Boolean)
				.join('&')

			if (queryString) {
				fullUrl += (fullUrl.includes('?') ? '&' : '?') + queryString
			}
			requestData = {} // GET请求的参数已经添加到URL中，清空data
		}

		// 开发环境才打印详细请求日志
		if (process.env.NODE_ENV === 'development') {
			console.log('发送请求:', {
				url: fullUrl,
				method: options.method || 'GET',
				data: requestData,
				header
			})
		}

		uni.request({
			url: fullUrl,
			method: options.method || 'GET',
			data: requestData,
			header,
			success: (res) => {
			// 开发环境才打印详细响应日志
			if (process.env.NODE_ENV === 'development') {
				console.log('请求响应:', {
					url: fullUrl,
					statusCode: res.statusCode,
					data: res.data
				})
			}

				// 处理响应
				if (res.statusCode >= 200 && res.statusCode < 300) {
					// 2xx状态码都认为是成功
					resolve(res.data)
				} else if (res.statusCode === 401) {
					// token过期，清除本地存储并跳转登录
					uni.removeStorageSync('token')
					uni.removeStorageSync('userInfo')
					uni.reLaunch({
						url: '/pages/login/login'
					})
					reject(new Error('登录已过期'))
				} else {
					console.error('请求失败:', res)
					reject(new Error(res.data?.message || `请求失败 (${res.statusCode})`))
				}
			},
			fail: (err) => {
				console.error('网络请求失败:', {
					url: fullUrl,
					error: err
				})
				uni.showToast({
					title: '网络请求失败',
					icon: 'none'
				})
				reject(new Error(`网络请求失败: ${err.errMsg || '未知错误'}`))
			}
		})
	})
}

// GET请求
export const get = (url, data = {}) => {
	return request({
		url,
		method: 'GET',
		data
	})
}

// POST请求
export const post = (url, data = {}) => {
	return request({
		url,
		method: 'POST',
		data
	})
}

// PUT请求
export const put = (url, data = {}) => {
	return request({
		url,
		method: 'PUT',
		data
	})
}

// DELETE请求
export const del = (url, data = {}) => {
	return request({
		url,
		method: 'DELETE',
		data
	})
}

export default request
