// 1. 将所有 import 语句改为 require()
const { defineConfig } = require('vite');
const uni = require('@dcloudio/vite-plugin-uni').default || require('@dcloudio/vite-plugin-uni');

// 2. 将 export default 改为 module.exports
module.exports = defineConfig({
  plugins: [
    uni(),
  ],
  // 开发服务器配置
  server: {
    port: 3000,
    host: '0.0.0.0',
    open: false,
    cors: true,
  },
  // 构建配置
  build: {
    target: 'es2015',
    cssCodeSplit: false,
    rollupOptions: {
      output: {
        manualChunks: false,
      },
    },
    chunkSizeWarningLimit: 2000,
  },
  // CSS 预处理器配置
  css: {
    preprocessorOptions: {
      scss: {
        additionalData: `@import "@/uni.scss";`,
      },
    },
  },
  // 别名配置
  resolve: {
    alias: {
      '@': '/src',
      '@/components': '/components',
      '@/utils': '/utils',
      '@/api': '/api',
      '@/config': '/config',
    },
  },
  // 开发模式下的优化
  optimizeDeps: {
    include: [
      'vue',
      'vue-router',
      'pinia',
      '@dcloudio/uni-app',
    ],
  },
});